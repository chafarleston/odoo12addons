{
    'name': u'Reportes de Pedidos fabricados',
    'version': '1.0',
    'author': 'facturaloperu',
    'website': 'facturaloperu.com',
    'category': 'Sale',
    'description': u'''
        Reportes de Pedidos fabricados
    ''',
    'depends': [
        'mrp'
    ],
    'data': [
        'reports/sale_order.xml'
    ],
    'installable': True,
    'active': False,
}
