# -*- encoding: utf-8 -*-
{
    'name': 'Consulta RUC/DNI',
    'summary': "Consulta de documentos RUC/DNI",
    'version': '1.0',
    'author': '',
    'website': '',
    'category': '',
    'license': 'AGPL-3',
    'depends': [
        'l10n_pe_sunat_data'
    ],
    'data': [
      'views/res.xml'
    ],
    'installable': True,
}
