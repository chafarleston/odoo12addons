Módulo desarrollado como complemento de facturación electrónica y compatibilidad con la API del Facturador Electrónico para contabilidad


Instalación
-----------

* Para instalar con Docker puede observar el proceso que utilizamos en el repositorio: https://gitlab.com/rash07/facturaloperu_odoo_12
* De poseer un instalación propia debe añadirlo en sus addons, puede descargarlos todos en: https://gitlab.com/maicoldlb/addons_facturalo_12

Autor
-----

**FacturaloPeru** http://facturaloperu.com
