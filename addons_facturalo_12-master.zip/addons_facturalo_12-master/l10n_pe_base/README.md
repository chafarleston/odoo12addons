Módulo desarrollado para agregar funciones generales que añaden información extra a la facturación electrónica


Instalación
-----------

* Para instalar con Docker puede observar el proceso que utilizamos en el repositorio: https://gitlab.com/rash07/facturaloperu_odoo_12
* De poseer un instalación propia debe añadirlo en sus addons, puede descargarlos todos en: https://gitlab.com/maicoldlb/addons_facturalo_12

Autor
-----

**FacturaloPeru** http://facturaloperu.com
