* Create a Sales Order and confirm.
* Deliver its pickings totally or partially.
* Create an invoice of the goods delivered.
* If you open invoice form, you must see a new Pickings tab with information
  about them.
