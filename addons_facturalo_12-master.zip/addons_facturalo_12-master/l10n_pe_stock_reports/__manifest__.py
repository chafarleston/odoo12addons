{
    'name': u'Reportes de Guías de remisión electrónicas',
    'version': '1.0',
    'author': 'facturaloperu',
    'website': 'facturaloperu.com',
    'category': 'Stock',
    'description': u'''
        Reportes de Guias de remisión electrónico
    ''',
    'depends': [
        'l10n_pe_stock'
    ],
    'data': [
        'report/stock.xml'
    ],
    'installable': True,
    'active': False,
}
