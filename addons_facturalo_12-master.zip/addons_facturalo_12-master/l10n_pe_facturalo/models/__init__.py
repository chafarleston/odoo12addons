# -*- coding: utf-8 -*-

from . import account
from . import res
from . import stock
from . import res_config_settings
from . import account_invoice
from . import account_invoice
